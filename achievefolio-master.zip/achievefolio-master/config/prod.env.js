'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_ENDPOINT: '"https://afternoon-dusk-12575.herokuapp.com"'
}
